/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui.pages;

import java.awt.CardLayout;
import javax.swing.JPanel;
import service.MyBookService;

/**
 *
 * @author MARIA
 */
public class PagesController {
    
   
    
    
    public static HomePage homePage = new HomePage();
    public static LibraryPage libraryPage = new LibraryPage();
    public static ArchivePage archivePage = new ArchivePage();
    public static AboutPage aboutPage= new AboutPage();
    public static AddPage addPage = new AddPage();
   
}
