/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui.pages;

/**
 *
 * @author MARIA
 */
public class PagesController {
    public static HomePage homePage = new HomePage();
    public static LibraryPage libraryPage = new LibraryPage();
    public static SearchPage searchPage = new SearchPage();
    public static AddPage addPage = new AddPage();
    public static AboutPage aboutPage = new AboutPage();
    public static ArchivePage archivePage = new ArchivePage();
}
